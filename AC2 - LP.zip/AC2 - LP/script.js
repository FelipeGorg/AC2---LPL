// 1 – (1 ponto) Ao cadastrar os produtos, uma loja percebeu que alguns produtos foram cadastrados
//  de forma errada. Atualize o array corrigindo os valores que necessitam de correção. 
// (Não é necessário o uso de forEach neste exercício)

let produtos = ["Celuar", "Mouse", "Monitor", "Notebbok", "Impressora", "Teclado", "Telveisão", "Fone", "Webcam", "HD Externo"];
produtos[0] = "Celular";
produtos[3] = "Monitor";
produtos[6] = "Televisão";

console.log(produtos)

// 2 – (1 ponto) Dado um array, adicione em um novo array todos os números, porém se o número for ímpar, ele
// deve ser multiplicado por um número aleatório entre 1 e 10.

let numeroAleatorio = Math.floor(Math.random() * 10);

let numeross = [2, 5, 8, 13, 16, 21];
// //Adicionar a uma array novo
let novoArray = []

// //se o numero for impar, multiplicar por dois
numeross.forEach(function (numero) {
    if (numero % 2 === 0) {
        numero * numeroAleatorio;
        novoArray.push(numero)
    } else { novoArray.push(numero) }
})

console.log(novoArray)

// 3 – (1 ponto) Dado o array abaixo, insira em um novo array todos os números arredondados para cima.

let numeros = [1.2, 3.7, 4.5, 6.1, 8.9];
let numerosCorrigidos = [];
numeros.forEach(function (numero) {
    Math.round(numero)
    numerosCorrigidos.push(numero)
})

console.log(numerosCorrigidos)

// 4 – (1 ponto) Faça um programa que receba seu nome completo(preencha com o seu nome verdadeiro) e printe no console
// quantas letras ele possui. Lembre-se que você deverá fazer uma condição para que ele não conte os espaços.

const nome = prompt("Digite seu nome completo!");
let palavras = nome.split('')
let contador = 0;

palavras.forEach(function (palavra) {
    if (palavra != " ") {
        contador++
    }
})

console.log(contador)
// 5 - (1 ponto) Dado o array numerosOriginais, você deve utilizar forEach para adicionar os números do array
//  novosNumeros no início do array numerosOriginais, de forma que o array final seja:

let novosNumeros = [1, 2, 3];
let numerosOriginais = [4, 5, 6];

novosNumeros.forEach(function (numero) {
    numerosOriginais.unshift(numero)
})

console.log(numerosOriginais)
